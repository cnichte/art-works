interface Props {
  // eslint-disable-next-line react/require-default-props
  value?: string;
  // eslint-disable-next-line react/require-default-props
  onChange?: (value: string) => void;
}

// TODO: Die Formular-Buttons...
