
/**
 * dispatches all the ipc requests from the frontend,
 * to database commands.
 */
export class Request_Dispatcher {
    constructor(){
        
    }

    public dispatch_requests(): void{
        console.log("Dispatch all the requests from the frontend");
    }
}