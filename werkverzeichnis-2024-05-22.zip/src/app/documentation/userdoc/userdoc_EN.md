TODO: Engliche Übersetzung des Benutzerhandbuchs.
