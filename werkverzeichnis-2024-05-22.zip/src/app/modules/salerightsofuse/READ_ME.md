# Module Sale Rights Of Use
