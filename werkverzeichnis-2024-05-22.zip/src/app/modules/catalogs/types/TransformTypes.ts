type FrontmatterType = 'yaml' | 'toml' | 'json';

// eslint-disable-next-line import/prefer-default-export
export { FrontmatterType };
