// import { Tldraw } from '@tldraw/tldraw'
// import '@tldraw/tldraw/tldraw.css'

/**
 * Das Formular ist in Tabs organisiert.
 * https://ant.design/components/tabs
 *
 * @returns
 * <Tldraw />
 */
function WhiteboardForm() {
  return (
		<div style={{ position: 'fixed', inset: 0 }}>
			Hello World
		</div>
	)
}

export default WhiteboardForm;
