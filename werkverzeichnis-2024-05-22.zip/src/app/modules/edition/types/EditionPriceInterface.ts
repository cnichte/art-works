export interface EditionPriceI {
  // Userdata
  id: string;
  name: string;
  numberStart: number;
  numberEnd: number;
  price: number;
  sales: string[];
}
